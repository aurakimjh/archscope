Synthetic-only bootstrap mapping. Exact millisecond-to-second conversion and zero preservation; unknown producer versions refuse. No real producer qualification.
